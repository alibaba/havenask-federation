"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "AppBootstrap", {
  enumerable: true,
  get: function () {
    return _app_bootstrap.AppBootstrap;
  }
});

var _app_bootstrap = require("./app_bootstrap");