Contains the vislib visualizations. These are the classical area/line/bar, pie, gauge/goal and 
heatmap charts.
