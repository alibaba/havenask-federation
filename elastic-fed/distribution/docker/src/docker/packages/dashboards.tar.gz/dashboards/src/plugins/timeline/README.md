Contains the deprecated timeline application. For the timeline visualization,
which also contains the timeline APIs and backend, look at the vis_type_timeline plugin.
