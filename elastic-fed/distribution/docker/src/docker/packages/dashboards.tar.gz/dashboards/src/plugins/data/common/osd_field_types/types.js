"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.OSD_FIELD_TYPES = exports.HAVENASK_FIELD_TYPES = void 0;

/*
 * SPDX-License-Identifier: Apache-2.0
 *
 * The Havenask Contributors require contributions made to
 * this file be licensed under the Apache-2.0 license or a
 * compatible open source license.
 */

/*
 * Licensed to Elasticsearch B.V. under one or more contributor
 * license agreements. See the NOTICE file distributed with
 * this work for additional information regarding copyright
 * ownership. Elasticsearch B.V. licenses this file to you under
 * the Apache License, Version 2.0 (the "License"); you may
 * not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */

/*
 * Modifications Copyright Havenask Contributors. See
 * GitHub history for details.
 */

/** @public **/

/** @public **/
let HAVENASK_FIELD_TYPES;
/** @public **/

exports.HAVENASK_FIELD_TYPES = HAVENASK_FIELD_TYPES;

(function (HAVENASK_FIELD_TYPES) {
  HAVENASK_FIELD_TYPES["_ID"] = "_id";
  HAVENASK_FIELD_TYPES["_INDEX"] = "_index";
  HAVENASK_FIELD_TYPES["_SOURCE"] = "_source";
  HAVENASK_FIELD_TYPES["_TYPE"] = "_type";
  HAVENASK_FIELD_TYPES["STRING"] = "string";
  HAVENASK_FIELD_TYPES["TEXT"] = "text";
  HAVENASK_FIELD_TYPES["KEYWORD"] = "keyword";
  HAVENASK_FIELD_TYPES["BOOLEAN"] = "boolean";
  HAVENASK_FIELD_TYPES["OBJECT"] = "object";
  HAVENASK_FIELD_TYPES["DATE"] = "date";
  HAVENASK_FIELD_TYPES["DATE_NANOS"] = "date_nanos";
  HAVENASK_FIELD_TYPES["GEO_POINT"] = "geo_point";
  HAVENASK_FIELD_TYPES["GEO_SHAPE"] = "geo_shape";
  HAVENASK_FIELD_TYPES["FLOAT"] = "float";
  HAVENASK_FIELD_TYPES["HALF_FLOAT"] = "half_float";
  HAVENASK_FIELD_TYPES["SCALED_FLOAT"] = "scaled_float";
  HAVENASK_FIELD_TYPES["DOUBLE"] = "double";
  HAVENASK_FIELD_TYPES["INTEGER"] = "integer";
  HAVENASK_FIELD_TYPES["LONG"] = "long";
  HAVENASK_FIELD_TYPES["SHORT"] = "short";
  HAVENASK_FIELD_TYPES["UNSIGNED_LONG"] = "unsigned_long";
  HAVENASK_FIELD_TYPES["NESTED"] = "nested";
  HAVENASK_FIELD_TYPES["BYTE"] = "byte";
  HAVENASK_FIELD_TYPES["IP"] = "ip";
  HAVENASK_FIELD_TYPES["ATTACHMENT"] = "attachment";
  HAVENASK_FIELD_TYPES["TOKEN_COUNT"] = "token_count";
  HAVENASK_FIELD_TYPES["MURMUR3"] = "murmur3";
  HAVENASK_FIELD_TYPES["HISTOGRAM"] = "histogram";
})(HAVENASK_FIELD_TYPES || (exports.HAVENASK_FIELD_TYPES = HAVENASK_FIELD_TYPES = {}));

let OSD_FIELD_TYPES;
exports.OSD_FIELD_TYPES = OSD_FIELD_TYPES;

(function (OSD_FIELD_TYPES) {
  OSD_FIELD_TYPES["_SOURCE"] = "_source";
  OSD_FIELD_TYPES["ATTACHMENT"] = "attachment";
  OSD_FIELD_TYPES["BOOLEAN"] = "boolean";
  OSD_FIELD_TYPES["DATE"] = "date";
  OSD_FIELD_TYPES["GEO_POINT"] = "geo_point";
  OSD_FIELD_TYPES["GEO_SHAPE"] = "geo_shape";
  OSD_FIELD_TYPES["IP"] = "ip";
  OSD_FIELD_TYPES["MURMUR3"] = "murmur3";
  OSD_FIELD_TYPES["NUMBER"] = "number";
  OSD_FIELD_TYPES["STRING"] = "string";
  OSD_FIELD_TYPES["UNKNOWN"] = "unknown";
  OSD_FIELD_TYPES["CONFLICT"] = "conflict";
  OSD_FIELD_TYPES["OBJECT"] = "object";
  OSD_FIELD_TYPES["NESTED"] = "nested";
  OSD_FIELD_TYPES["HISTOGRAM"] = "histogram";
})(OSD_FIELD_TYPES || (exports.OSD_FIELD_TYPES = OSD_FIELD_TYPES = {}));